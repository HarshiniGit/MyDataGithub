### Gramener Case Study ###

############################
### Submitted by:		 ###
### 1. Harshini T		 ###
### 2. Aishwarya S	     ###
### 3. Indumathi B S	 ###
### 4. Abhishek Kulkarni ###
############################

# Importing the required libraries into our R environment

install.packages("dplyr")
install.packages("stringr")
install.packages("gridExtra")
install.packages("tidyr")
install.packages("lubridate")
install.packages("ggplot2")
install.packages("corrplot")
install.packages("sqldf")

library(dplyr)
library(stringr)
library(gridExtra)
library(tidyr)
library(lubridate)
library(ggplot2)
library(corrplot)
library(sqldf)

# Setting the Working Directory
# setwd("D:/Users/htarigop/Desktop/DS/Gramener case study")

# Loading the data set in a variable Consumer:

LC_Data_Set<-read.csv("loan.csv",stringsAsFactors = F,header = T)

#------- Let us now being with our Data Cleaning -------#

# Structure of the data set:

str(LC_Data_Set)

# There are 111 variables and a large number of them seem to have a number of NA values
#  Let us see whether any columns have all NA's and eliminate them if present

# # If the no of NA's in a column equals the total no. of rows then all values in the column are NA
# # Store the column no. of such columns in a variable

# There are many columns with only a single unique value- e.g. NA, 0, F etc. Lets us drop
# all such columns as they will not be useful for EDA or visualisation

# Checking for unique values:

unique_values<-lapply(LC_Data_Set,function(x) length(unique(x)))
unique_values

#There are columns with only one unique value hence remove them as there
#are not of significance for analysis


#Removing columns with one unique value:

LC_Unique_Data_Set<-Filter(function(x)(length(unique(x))>1),LC_Data_Set)

# Since there are still a large no. of variables,
# let us look at them 10 at a time to understand which ones may need cleaning or conversion

# - Checking Columns 0-to-25 #

str(LC_Unique_Data_Set[,1:25])

# term and int_rate are of char format. We need to convert them to numbers

LC_Unique_Data_Set <- LC_Unique_Data_Set %>% mutate(int_rate = gsub("%", "", int_rate),
                                  int_rate = as.numeric(int_rate),
                                  term = gsub(" months", "", term),
                                  term = as.numeric(term),
                                  issue_d = paste("01",issue_d,sep="-"),
                                  issue_d = parse_date_time(issue_d, orders = c("dmy"), locale = "eng"))


# # - Checking Columns 26-to-51 #
str(LC_Unique_Data_Set[,26:51])

# Convert earliest_cr_line to date format

LC_Unique_Data_Set <- LC_Unique_Data_Set %>% mutate(earliest_cr_line = paste("01",earliest_cr_line,sep="-"),
                                  earliest_cr_line = parse_date_time(earliest_cr_line, orders = c("dmy"),
                                                                     locale = "eng"))
# Convert revol_util to number by removing % sign

LC_Unique_Data_Set <- LC_Unique_Data_Set %>% mutate(revol_util = gsub("%", "", revol_util),
                                  revol_util = as.numeric(revol_util))

### Dropping unwanted columns due to: ###

# 1) Too many unique character values
# 2) Should not have any logical bearing on the loan_status

rm_cols<-c("emp_title","url","member_id","zip_code")
LC_Unique_Data_Set <- LC_Unique_Data_Set[ ,!(names(LC_Unique_Data_Set) %in% rm_cols)]

#------- Data Cleansing completed successfully -------#

###################################################################

#Plotting loan_status types:

ggplot(LC_Unique_Data_Set,aes(x=loan_status))+geom_bar(aes(fill=loan_status))+
  geom_text(stat='count',aes(label=..count..),vjust=-0.1) +
  ggtitle("Analysis of various Loan Status")

## Buildup a data set which has only "Charged off Loans" and "Fully Paid" loans for analysis of
## closed loan instruments for understanding the trend

LC_Loan_Status <- filter(LC_Unique_Data_Set,loan_status != "Current")

#Build data set which has only Charged Off loans for analysis
LC_Charged_Off <- filter(LC_Loan_Status,loan_status == "Charged Off")

#############################################################
##### Univariate & segmented univariate analysis#############
#############################################################

#Let's see how individual variables influence on Loan Status in this analysis

#1.Plotting Grade vs Loan status:

ggplot(LC_Loan_Status,aes(x=grade,fill=loan_status))+geom_bar()+
  geom_text(stat='count',aes(label=..count..),position=position_stack(vjust=0.5),check_overlap = T)+
  labs(title="Grade Vs Loan Status",x="Grade",y="Count",fill="Loan Status")+
   scale_fill_manual(values = c("#ECA0D9", "#C0A7E8"))  

#Grade B has the highest number of defaulters

#2. Plotting Sub grade vs loan status -- only for charged off

ggplot(LC_Charged_Off, aes(x= sub_grade,fill=loan_status)) + geom_bar() +
  geom_text(stat='count',aes(label=..count..),vjust=-0.1)+ 
xlab("Loan_SubGrade")+ylab("Count of Charged-off Applicants") +
  ggtitle("Loan Sub-Grade versus Charged off Loan Applicants") 
  
#Grade B5 has the highest number of defaulters

#3. Plotting Term of the loan vs Loan status:

ggplot(LC_Loan_Status,aes(x=factor(term),fill=loan_status))+geom_bar()+
  geom_text(stat='count',aes(label=..count..),position=position_stack(vjust=0.5))+  
  labs(title="Loan Term Vs Loan Status",x="Term",y="Count",fill="Loan Status")

#36 months term category has more number of defaulters

#4. Plotting Purpose vs Loan status:

ggplot(LC_Loan_Status,aes(x=purpose,fill=loan_status))+geom_bar()+
  geom_text(stat='count',aes(label=..count..),position=position_stack(vjust=0.2),check_overlap = T)+  
  labs(title="Purpose Vs Loan Status",x="Purpose",y="Count",fill="Loan Status")+
   scale_fill_manual(values = c("#F38461", "#F5B558"))

#Debt consolidation purpose has highest number of defaulters

#5. Plotting Verification Status vs Loan status:

ggplot(LC_Loan_Status,aes(x=verification_status,fill=loan_status))+geom_bar()+
  geom_text(stat='count',aes(label=..count..),position=position_stack(vjust=0.5))+ 
  labs(title="Verification Status Vs Loan Status",x="Verification Status",y="Count",fill="Loan Status") +
  scale_fill_manual(values = c("#6DD8E7", "#4EF39E"))

#People whose status were not verified are seem to be more charged off

#6. Plotting int_rate Vs loan_status:

  ggplot(LC_Loan_Status, aes(x=int_rate),fill="pink") +   
  geom_histogram(aes(y=..density..),bins=30,colour="black",fill="#FCD6AB")+
                  geom_density(aes(y=..density..),colour ="#160918") +
     ylab("Density") + xlab("int_rate") + ggtitle("Analysis of int_rate v/s loan_status ") 


#7. Plotting Home Ownership distribution vs Loan status:

ggplot(LC_Loan_Status,aes(x=home_ownership,fill=loan_status))+geom_bar()+
  geom_text(stat='count',aes(label=..count..),position=position_stack(vjust=0.5))+  
  labs(title="Home Ownership Vs Loan Status",x="Home Ownership",y="Count",fill="Loan Status") +
  scale_fill_manual(values = c("#FCD6AB", "pink"))

#People with "Rent" as their home ownership are more likely to be defaulters

#8. Plotting of Loan Status over Employment Duration(Emp_length)

LC_Loan_Status$emp_length<- gsub("< 1 year","Fresher", LC_Loan_Status$emp_length)
LC_Loan_Status$emp_length<- gsub("10\\+ years", "Experienced", LC_Loan_Status$emp_length) 
LC_Loan_Status$emp_length<- gsub("n/a", "Unknown", LC_Loan_Status$emp_length) 

 ggplot(data= subset(LC_Loan_Status, is.na(LC_Loan_Status$emp_length)==F), 
                                  aes(x= loan_status,  group=emp_length)) + 
  geom_bar(aes(y = ..prop.., fill = factor(..x..)), stat="count",width = 0.8) + 
  geom_text(aes( label = scales::percent(..prop..),y= ..prop.. ), 
            stat= "count", vjust = 0.8) +
    facet_wrap(~emp_length) + 
  scale_y_continuous(labels = scales::percent) + xlab("Loan Status over Employment Duration") +
  ylab("Applicants Percentage") + ggtitle("Validation of Loan Status over Employment Duration") +
  scale_fill_discrete(name = "Loan_Status")

# People with 10+ years experience are more likely to be defaulters
 
#9. Plotting Public Derogatory Record vs Loan status:

 LC_Loan_Status$pub_rec<-str_replace(LC_Loan_Status$pub_rec,pattern="NA","")
ggplot(LC_Loan_Status,aes(x=pub_rec,fill=loan_status))+geom_bar()+
  geom_text(stat='count',aes(label=..count..),position=position_stack(vjust=0.5))+  
  labs(title="Public Derogatory Record Vs Loan Status",x="Public Record",y="Count",fill="Loan Status") +
  scale_fill_manual(values = c("#F6BB54", "#B0ABB3"))

#10. Plotting Public Bankruptcy Records vs Loan status: 

LC_Loan_Status$pub_rec_bankruptcies<-str_replace(LC_Loan_Status$pub_rec_bankruptcies,pattern="NA","")
ggplot(LC_Loan_Status,aes(x=pub_rec_bankruptcies,fill=loan_status))+geom_bar()+
  geom_text(stat='count',aes(label=..count..),position=position_stack(vjust=0.5),check_overlap = T)+  
  labs(title="Public Bankruptcy Records Vs Loan Status",x="Pub Rec Bankruptcies",y="Count",fill="Loan Status") +
  scale_fill_manual(values = c("LightCoral", "SandyBrown"))

#People with 0 public records and bank ruptcy are more likely to be charged off

####Derived Metrics#####

#Extracting year and month from issue_d:

#Year
LC_Loan_Status$issue_year<-format(LC_Loan_Status$issue_d,"%Y") 

#Month
LC_Loan_Status$issue_month<-format(LC_Loan_Status$issue_d,"%m")  

#Plotting graph for issue date vs loan_status based on year wise & month wise

#11. Plotting Issue Year over loan_status

ggplot(LC_Loan_Status,aes(x=issue_year,fill=loan_status))+geom_bar()+
  geom_text(stat='count',aes(label=..count..),position=position_stack(vjust=0.5))+  
  labs(title="Issue Year Vs Loan Status",x="Issue Year",y="Count",fill="Loan Status") +
  scale_fill_manual(values = c("IndianRed", "LightSalmon"))

#2011 has seen the highest number of defaulters

#12. Plotting Issue Month over loan_status

ggplot(LC_Loan_Status,aes(x=issue_month,fill=loan_status))+geom_bar()+
  geom_text(stat='count',aes(label=..count..),position=position_stack(vjust=0.5))+  
  labs(title="Issue Month Vs Loan Status",x="Issue Month",y="Count",fill="Loan Status") +
  scale_fill_manual(values = c("red", "#008080"))

#December has seen the highest number of defaulters

# Analysis of Annual Income 
# It has values which fall out of range hence ignoring those outliers
# which are greater than Q3 + 1.5(IQR)
income_outlier <- as.numeric(quantile(LC_Loan_Status$annual_inc)[4] + 1.5*IQR(LC_Loan_Status$annual_inc))
income_outlier

annual_income<-LC_Loan_Status %>% filter(annual_inc <= income_outlier)

annual_income_bins<- sqldf("SELECT CASE
                           WHEN annual_inc BETWEEN 0 AND 19999 THEN '0-20k'
                           WHEN annual_inc BETWEEN 20000 AND 39999 THEN '20k-40k'
                           WHEN annual_inc BETWEEN 40000 AND 59999 THEN '40k-60k'
                           WHEN annual_inc BETWEEN 60000 AND 79999 THEN '60k-80k'
                           WHEN annual_inc BETWEEN 80000 AND 99999 THEN '80k-100k'
                           WHEN annual_inc BETWEEN 100000 AND 119999 THEN '100k-120k'
                           WHEN annual_inc BETWEEN 120000 AND 145000 THEN '120k-145k'
                           END AS bins,loan_status,
                           COUNT(*) AS count
                           FROM annual_income
                           GROUP BY bins,loan_status")

#13. Plotting annual income Vs Loan status:

ggplot(annual_income_bins, aes(x=bins,y = count,fill=loan_status)) + 
  geom_bar(stat = "identity") + theme(legend.position = "bottom") + 
  geom_text(aes(label=count),position = position_stack(vjust=0.5),check_overlap = T) + xlab("Annual Income Bins")+ 
  ylab("Frequency") + ggtitle("Annual Income Bins Vs Loan Status")+
  scale_fill_manual(values = c("grey","pink"))
 
#People with income between 40k to 60k dollars are more likely to be defaulters

#14. Plotting delinq_2yrs Vs Loan status:
 
ggplot(LC_Loan_Status,aes(x=factor(delinq_2yrs),fill=loan_status))+geom_bar()+
  geom_text(stat='count',aes(label=..count..),position=position_stack(vjust=0.2))+  
  labs(title="Delinquency Vs Loan Status",x="Delinquency",y="Count",fill="Loan Status")

 
#Data Analysis of revol_util

# Checking NAs in revol_util:
length(which(is.na(LC_Loan_Status$revol_util)))

#Median & mean of this revol_util
mean(LC_Loan_Status$revol_util,na.rm=T)

median(LC_Loan_Status$revol_util,na.rm=T)

#Choosing the median for replacement of NA
LC_Loan_Status[which(is.na(LC_Loan_Status$revol_util)),"revol_util"] <- median(LC_Loan_Status$revol_util,na.rm=TRUE)

#15. Plotting revol_util Vs loan_status:
ggplot(LC_Loan_Status) + 
  geom_histogram(aes(x=revol_util,fill=loan_status),col="black",position="fill",bins=20) +
  scale_y_continuous(breaks=seq(0,1,0.1)) +
  labs(title="Revolving credit Vs Loan Status",x="Revolving Utilization",y="Percentage",fill="Loan Status")
  

#16. Plotting Loan Amount Based on Loan Status

#Analysis of loan amount Vs loan status
loan_amount_bins<- sqldf("SELECT CASE
                         WHEN loan_amnt BETWEEN 0 AND 4999 THEN '0-5k'
                         WHEN loan_amnt BETWEEN 5000 AND 9999 THEN '5k-10k'
                         WHEN loan_amnt BETWEEN 10000 AND 14999 THEN '10k-15k'
                         WHEN loan_amnt BETWEEN 15000 AND 19999 THEN '15k-20k'
                         WHEN loan_amnt BETWEEN 20000 AND 24999 THEN '20k-25k'
                         WHEN loan_amnt BETWEEN 25000 AND 29999 THEN '25k-30k'
                         WHEN loan_amnt BETWEEN 30000 AND 35000 THEN '30k-35k'
                         END AS bins,loan_status,
                         COUNT(*) AS frequency
                         FROM LC_Loan_Status
                         GROUP BY bins,loan_status")

#Plotting of loan amount Vs loan status

ggplot(loan_amount_bins, aes(x=bins,y = frequency,fill=loan_status)) + 
  geom_bar(stat = "identity") + theme(legend.position = "bottom") + 
  geom_text(aes(label=frequency),position = position_stack(vjust=0.5),check_overlap = T) + xlab("Loan Amount Bins")+ 
  ylab("Frequency") + ggtitle("Loan Amount Bins Vs Loan Status")+
  scale_fill_manual(values = c("grey","skyblue"))

#People who take loan between 5k and 10k dollars are more likely to be defaulters

#17. Plotting Installment vs Loan Status

installment_status <- sqldf("SELECT CASE
                            WHEN installment BETWEEN 0 AND 199 THEN '0-200'
                            WHEN installment BETWEEN 200 AND 399 THEN '200-400'
                            WHEN installment BETWEEN 400 AND 599 THEN '400-600'
                            WHEN installment BETWEEN 600 AND 799 THEN '600-800'
                            WHEN installment BETWEEN 800 AND 999 THEN '800-1K'
                            WHEN installment BETWEEN 1000 AND 1199 THEN '1K-1.2K'
                            WHEN installment BETWEEN 1200 AND 1399 THEN '1.2K-1.4K'
                            ELSE '1.4K+' END AS bins,loan_status,
                            COUNT(*) AS total
                            FROM LC_Loan_Status
                            GROUP BY loan_status,bins")

ggplot(installment_status, aes(x=bins,y = total,fill=loan_status)) + 
  geom_bar(stat = "identity") + theme(legend.position = "bottom") + 
  geom_text(aes(label=total),position=position_stack(vjust=0.5),check_overlap = T) + xlab("Installment Bins")+ 
  ylab("Frequency") + ggtitle("Installments Vs Loan Status")+
  scale_fill_manual(values = c("RoyalBlue","SteelBlue"))

#People who pay monthly installments in the range 200 to 400 dollars are more likely to be defaulters

# Inference from Univariant Analysis

# Variables that effect the Fully paid loans vs Charge off are enlisted below:
# 1. sub_grade
# 2. public bankruptcy records
# 3. verification_status
# 4. revol_util_range
# 5. home_ownership
# 6. loan_amnt_range
# 7. term
# 8. purpose


# Hurry!! We have completed analyzing Univariate
# Now it's time to make our hands dirty on making Bi-Variate Analysis
# Here, we aim to analyze the various categorical variables over Loan Status 

# a) Analysis of Grades vs Loan_Amount and Loan_Status:

ggplot(LC_Loan_Status) + geom_boxplot(aes(x=grade,y=loan_amnt,fill=loan_status)) + 
  scale_y_continuous(breaks=seq(0,36000,5000)) +
  labs(title="Grade Versus LoanAmount & LoanStatus",x="Grades",y="Loan Amount",fill="Loan Status")+
  scale_fill_manual(values = c("Turquoise", "Chocolate"))

#There seems to be direct relationship between loan amount and grades hence grade can be 
#considered as a factor of defaulters

# b) Influence of Loan Amount and Sub-Grade over Loan Status

Amnt_Sub_Grade<-aggregate(LC_Loan_Status$loan_amnt,by=list(LC_Loan_Status$sub_grade,LC_Loan_Status$loan_status),mean,na.rm=T)

ggplot(Amnt_Sub_Grade,aes(x= factor(Group.1), y=x, fill=Group.2)) + 
  geom_bar(stat="identity",position = "dodge")  + 
  labs(title="Loan Amount and Sub-Grade over Loan Status",x="Loan Sub-Grade",
       y="Applicants Percentage",fill="Loan_Status")+
  scale_fill_manual(values = c("SteelBlue", "Orange"))

#There doesn't seem to be a clear correlation between sub grade and loan amount

# c) Influence of Annual Income disbursement and Grade Vs Loan Status 

LoanAmtDist_Loan_Status_vs_Grade = LC_Loan_Status %>% 
  select(loan_status, annual_inc, grade) %>% 
  group_by(loan_status, grade) %>% 
  summarise(Amount = round(mean(annual_inc)))

ggplot(LoanAmtDist_Loan_Status_vs_Grade, aes(x = grade,y = Amount, fill = loan_status)) + 
  geom_bar(stat="identity",position = "dodge") + geom_text(aes(label = Amount ), position= position_dodge(width=1.0), 
  vjust=-0.1, color="black") + theme(legend.position = "bottom") +
  labs(title = "Influence of Annual Income disbursement and Grade Vs Loan Status",
       x = "Grades",
       y = "Amount") 

#As annual income increases grade also increases so grade can be considered as a factor

# d) Influence of Loan amount distribution & Verification Status Vs Loan Status 

LoanAmtDist_Verification_vs_LoanStatus <- LC_Loan_Status %>% 
  select(loan_status, loan_amnt, verification_status) %>% 
  group_by(loan_status, verification_status) %>%
  summarise(loan = sum(loan_amnt) )

ggplot(LoanAmtDist_Verification_vs_LoanStatus, aes(x = verification_status,y = loan, fill = loan_status)) + 
  geom_bar(stat="identity",position = "dodge") + geom_text( aes(label = loan),position= position_dodge(width=1.0), vjust=-0.1, color="black") +
  theme(legend.position = "bottom") +
  labs(title = "Influence of Verification Status and Loan amount over Loan Status ",
       x = "Verification Status",
       y = "Amount") +
scale_fill_manual(values = c("BurlyWood", "DarkSeaGreen"))

#Number of defaulters are more among status verified people and with high loan amount 

# e) Influence of Loan amount distribution & Home Ownership Vs Loan Status 

LoanAmtDist_home_vs_LoanStatus <- LC_Loan_Status %>% 
  select(loan_status, loan_amnt, home_ownership) %>% 
  group_by(loan_status, home_ownership) %>%
  summarise(loan = round(mean(loan_amnt)))

ggplot(LoanAmtDist_home_vs_LoanStatus, aes(x = home_ownership,y = loan, fill = loan_status)) + 
  geom_bar(stat="identity",position = "dodge") + geom_text( aes(label = loan),position= position_dodge(width=1.0), vjust=-0.1, color="black") +
  theme(legend.position = "bottom") +
  labs(title = "Influence of Home Ownership and Loan amount over Loan Status ",
       x = "Home Ownership",
       y = "Loan Amount") +
  scale_fill_manual(values = c("RosyBrown", "DarkGray"))

#People with home ownership are the people with high loan amount and are more likely to be
#defaulters

# f) Influence of Loan Amount distribution and Purpose vs Loan Status

LoanAmt_Grade_vs_LoanStatus <- LC_Loan_Status %>% 
  select(loan_amnt, purpose, loan_status) %>% 
  group_by(purpose, loan_status) %>% 
  summarise(dist = round(mean(loan_amnt)))

ggplot(LoanAmt_Grade_vs_LoanStatus, aes(x = purpose,y = dist, fill = loan_status)) + 
  geom_bar(stat="identity",position = "dodge")  + 
  geom_text(aes(label = dist), position= position_dodge(width=1.0), vjust=-0.1, color="black") +
  theme(legend.position = "bottom") + 
  labs(title = "Influence of Loan Amount and Purpose over Loan Status",
       x = "Purpose",
       y = "Loan Amount")  +         
  scale_fill_manual(values = c("LightSalmon", "Brown"))

#People with small businees and high loan amount are more likley to be defaulters

# g) Influence of Grades and DTI over Loan Status

ggplot(LC_Loan_Status) + 
  geom_boxplot(aes(x=grade,y=dti,fill=loan_status)) + 
  geom_line(data=(LC_Loan_Status %>% 
                    group_by(grade) %>% 
                    summarize(avg_dti=mean(dti,na.rm=TRUE))),
            aes(x=grade,y=avg_dti,group=1)) +
  scale_y_continuous(breaks=seq(0,32,4)) +
  labs(title="Influence of DTI and Grades over Loan Status",x="Grade",y="DTI",fill="Loan Status")

#There seems to be direct relationship between the DTI and the Grade, therefore,
# between dti and grades, grades can be considered as a valid reflection for DTI data as well.


#################### Bivariant Analysis Ends ####################

# Inference: Mpst affecting factors are grade and loan amount

################ Let's now quickly look at Multivariant Analysis #################### 

# Let us analyse how multiple variables are influencing over load_status

# Wondering how co-relations between variables look?
# Let us go and dig them!

correlation_name= c("annual_inc", "loan_amnt", "delinq_2yrs","int_rate", "revol_util", "installment", "sub_grade", "dti")

correlation_variable <- select(LC_Loan_Status, one_of(correlation_name))
correlation_variable <- correlation_variable[complete.cases(correlation_variable), ]

# Now let's transform the character types into numeric one! #

correlation_variable$num_subgrade <- as.numeric(as.factor(correlation_variable$sub_grade))

# Removing the unwanted characters and sub grades #

correlation_variable <- select(correlation_variable, -sub_grade)

correlation <- cor(correlation_variable)
corrplot(correlation, method = "color", 
         title = "Correlation of Multiple Factors", 
         outline = T,
         type = "full", 
         order = "AOE", 
         number.digits = 2,
         number.cex = 0.75, 
         tl.cex = 0.9,
         bg="PapayaWhip",addCoef.col = "Black",col = colorRampPalette(c("LightCoral","Cornsilk","Purple"))(20))


#################################################
#Inference: Multivariant analysis
#As seen from the graph int_rate and num_subgrade are the most correlated factors
#and then comes loan_amnt and installment hence based on this combination,
#customers can be given loan
#################################################

