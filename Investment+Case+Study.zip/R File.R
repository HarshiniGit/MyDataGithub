#First set the working directory as follows:
#setwd("D:/Users/htarigop/Desktop/DS/Case study_1")

#Read companies data set:
companies<-read.delim("companies.txt",header=T,sep="\t")

#Read rounds2 data set:
rounds<-read.csv("rounds2.csv",header=T)

#Table 1.1: Understand the Data Set

#Data Cleaning:In order to merge two data sets companies and rounds2, we need to have one common column
#in which data should be of same case hence convert them to lower case as follows:

companies$permalink<-tolower(companies$permalink)
rounds$company_permalink<-tolower(rounds$company_permalink)

#1.Number of unique companies present in rounds2 data set:
length(unique(rounds$company_permalink))

#2.Number of unique companies present in companies data set:
length(unique(companies$permalink))

#3.Unique column in the companies data set:
for(i in 1:ncol(companies)){
  if(any(duplicated(companies[i]))){
    flag=0
  }else{
    flag=1
    unique_column=names(companies[i])
  }
}
unique_column



#4.To check whether extra companies are present in rounds2  data set compared to companies data set:
extra_rounds2<-merge(companies,rounds,by.x=c("permalink"),
                    by.y=c("company_permalink"),all.y = T)
length(unique(extra_rounds2$permalink))
print("N")

#5.Creation of master_frame:master_frame is the merged data set obtained by merging companies and rounds2
master_frame<-merge(companies,rounds,by.x=c("permalink"),
                    by.y=c("company_permalink"))
master_frame

#Number of observations in master_frame:
nrow(master_frame)

#Table 2.1: Average Values of Investments for Each of these Funding Types
agg<-aggregate(master_frame$raised_amount_usd,by=list(master_frame$funding_round_type),FUN=mean,na.rm=T)

#1.Average funding amount of venture type:
agg_venture<-subset(agg,agg$Group.1=="venture")
colnames(agg_venture)<-c("Funding Type","Average funding amount")
print.data.frame(agg_venture,digits = 10)

#2.Average funding amount of angel type:
agg_angel<-subset(agg,agg$Group.1=="angel")
colnames(agg_angel)<-c("Funding Type","Average funding amount")
print.data.frame(agg_angel,digits = 10)

#3.Average funding amount of seed type:
agg_seed<-subset(agg,agg$Group.1=="seed")
colnames(agg_seed)<-c("Funding Type","Average funding amount")
print.data.frame(agg_seed,digits = 10)

#4.Average funding amount of private_equity type:
agg_private_equity<-subset(agg,agg$Group.1=="private_equity")
colnames(agg_private_equity)<-c("Funding Type","Average funding amount")
print.data.frame(agg_private_equity,digits = 10)


#5.Most suitable funding type considering the constraint of investing in the range of 5 to 15 million USD
above_result<-subset(agg,agg$Group.1 %in% c("venture","angel","seed","private_equity"))

for(i in 1:nrow(above_result)){ 
   if(above_result[i,2] >= 5000000 & above_result[i,2] <= 15000000){
      suitable_amt = print(above_result[i,2],digits=10)
      }
  }

suitable_fund_type<-as.data.frame(subset(agg$Group.1,agg$x==suitable_amt))
names(suitable_fund_type)<-"most_suitable_fund_type"
suitable_fund_type


#Table 3.1: Analysing the Top 3 English-Speaking Countries
#Narrowing down the countries based on suitable funding type:
venture_country<-subset(master_frame,master_frame$funding_round_type == "venture")
total_funding_venture<- aggregate(venture_country$raised_amount_usd,
                                  by=list(venture_country$country_code),
                                  FUN=sum,na.rm = T)

#Ordering the countries based on amount to find top 9 countries:
total_funding_venture <- total_funding_venture[order(-total_funding_venture$x) , ] 

top9<-head(subset(total_funding_venture,!total_funding_venture$Group.1== ""),n=9)
top9

#Short listing the English speaking country codes
eng_speak<-subset(top9,top9$Group.1 %in% c("USA","GBR","IND","CAN"))

#To get names of countries based on their codes:
library(countrycode)
Eng_Country_name<-countrycode(eng_speak$Group.1, origin="iso3c", destination="country.name")
Eng_Country_name

#1.Top English speaking country:
top_1<-Eng_Country_name[1]
top_1

#2.Second English speaking country
top_2<-Eng_Country_name[2]
top_2

#3.Third English speaking country
top_3<-Eng_Country_name[3]
top_3

#Checkpoint 4: Sector Analysis 1 
#To manipulate strings, use "stringr" package.
#For the purpose of data cleaning, use "tidyr" package.
#For performing aggregations on the manipulated data, use "dplyr" package.

library(stringr)
library(tidyr)
library(dplyr)

#Read mapping data set
mapping<-read.csv("mapping.csv",stringsAsFactors=F)                  

#Conversion from wide format to long format:
sector<- gather(mapping,main_sector,my_val,Automotive...Sports:Social..Finance..Analytics..Advertising) 

#Neglecting rows which have my_val with "0" data
sector<- sector[!(sector$my_val==0), ]

#Neglecting "Blanks" sector as it is not one of the 8 major sectors
sector<- sector[!(sector$main_sector=="Blanks"), ]

#Data Cleaning:Names of category list have 0 in place of na. For example, Analytics is present as A0lytics.
#Hence replace 0 with na but numeric 0's should not be replaced for example "Enterprise 2.0"
sector$category_list<-str_replace_all(str_replace_all(sector$category_list,"0","na"),"Enterprise 2.na","Enterprise 2.0")

#Separating category_list into "primary sector" by extracting first string of category_list which is 
#separated by "|"
master_frame_1<-separate(master_frame,category_list,into="primary_sector",sep="\\|",extra="drop")

# Create a merged data frame with each primary sector mapped to one of the eight main sectors
merged_data_frame<-merge(master_frame_1,sector,by.x="primary_sector",by.y ="category_list")
merged_data_frame

#Table 5.1: Sector-wise Investment Analysis
#D1 data frame for "USA" containing the observations of "venture" type falling within 5-15 million USD: 
D1<- subset(merged_data_frame,merged_data_frame$country_code=="USA" & merged_data_frame$funding_round_type =="venture"
            & merged_data_frame$raised_amount_usd>= 5000000 & merged_data_frame$raised_amount_usd <= 15000000)

#Total number of investments for each main sector in a seaparate column "D1_no_of_inv":
D1_no_of_inv<- D1 %>% group_by(D1$main_sector) %>% summarise(count=n())
D1_no_of_inv

#Adding "D1_no_of_inv" column to D1 data frame:
D1<-merge(D1,D1_no_of_inv,by.x="main_sector",by.y = "D1$main_sector")

# Changing column names to meaningful names:
colnames(D1)[18]<-"no_of_inv"
colnames(D1_no_of_inv)[1]<-"D1_sector"

#Total amount invested in each main sector in a separate column "D1_total_inv":
D1_total_inv<- D1 %>% group_by(D1$main_sector) %>% summarise(sum(raised_amount_usd))
D1_total_inv

#Adding "D1_total_inv" column to D1 data frame:
D1<-merge(D1,D1_total_inv,by.x="main_sector",by.y = "D1$main_sector")

# Changing column name to meaningful names:
colnames(D1)[19]<-"total_amt_inv"

#D2 data frame for "GBR" containing the observations of "venture" type falling within 5-15 million USD:
D2<- subset(merged_data_frame,merged_data_frame$country_code=="GBR" & merged_data_frame$funding_round_type=="venture"
            & merged_data_frame$raised_amount_usd>= 5000000 & merged_data_frame$raised_amount_usd <= 15000000)

#Total number of investments for each main sector in a seaparate column "D2_no_of_inv":
D2_no_of_inv<- D2 %>% group_by(D2$main_sector) %>% summarise(count=n())
D2_no_of_inv

#Adding "D2_no_of_inv" column to D2 data frame:
D2<-merge(D2,D2_no_of_inv,by.x="main_sector",by.y = "D2$main_sector")

# Changing column names to meaningful names:
colnames(D2)[18]<-"no_of_inv"
colnames(D2_no_of_inv)[1]<-"D2_sector"

#Total amount invested in each main sector in a separate column "D2_total_inv":
D2_total_inv<- D2 %>% group_by(D2$main_sector) %>% summarise(sum(raised_amount_usd))
D2_total_inv

#Adding "D2_total_inv" column to D2 data frame:
D2<-merge(D2,D2_total_inv,by.x="main_sector",by.y = "D2$main_sector")

# Changing column name to meaningful names:
colnames(D2)[19]<-"total_amt_inv"

#D3 data frame for "IND" containing the observations of "venture" type falling within 5-15 million USD:
D3<- subset(merged_data_frame,merged_data_frame$country_code=="IND" & merged_data_frame$funding_round_type=="venture"
            & merged_data_frame$raised_amount_usd>= 5000000 & merged_data_frame$raised_amount_usd <= 15000000)

#Total number of investments for each main sector in a seaparate column "D3_no_of_inv":
D3_no_of_inv<- D3 %>% group_by(D3$main_sector) %>% summarise(count=n())
D3_no_of_inv

#Adding "D3_no_of_inv" column to D3 data frame:
D3<-merge(D3,D3_no_of_inv,by.x="main_sector",by.y = "D3$main_sector")

# Changing column names to meaningful names:
colnames(D3)[18]<-"no_of_inv"
colnames(D3_no_of_inv)[1]<-"D3_sector"

#Total amount invested in each main sector in a separate column "D3_total_inv":
D3_total_inv<- D3 %>% group_by(D3$main_sector) %>% summarise(sum(raised_amount_usd))
D3_total_inv

#Adding "D3_total_inv" column to D3 data frame:
D3<-merge(D3,D3_total_inv,by.x="main_sector",by.y = "D3$main_sector")

# Changing column name to meaningful names:
colnames(D3)[19]<-"total_amt_inv"

#Top 3 English countries are USA,GBR and IND

#1.Total number of investments in the above mentioned countries:
cnt_of_inv_D1<-length(D1$raised_amount_usd)
cnt_of_inv_D1
cnt_of_inv_D2<-length(D2$raised_amount_usd)
cnt_of_inv_D2
cnt_of_inv_D3<-length(D3$raised_amount_usd)
cnt_of_inv_D3

#2.Total amount of investment in the above mentioned countries:
total_amt_inv_D1<-sum(D1$raised_amount_usd,na.rm=T)
total_amt_inv_D1
total_amt_inv_D2<-sum(D2$raised_amount_usd,na.rm=T)
total_amt_inv_D2
total_amt_inv_D3<-sum(D3$raised_amount_usd,na.rm=T)
total_amt_inv_D3

#3.Top sector based on count of investments in the above mentioned countries:
d1<-D1_no_of_inv[order(D1_no_of_inv$count,decreasing = T), ]
top_sector_D1<-d1[1,1]
top_sector_D1

d2<-D2_no_of_inv[order(D2_no_of_inv$count,decreasing = T), ]
top_sector_D2<-d2[1,1]
top_sector_D2

d3<-D3_no_of_inv[order(D3_no_of_inv$count,decreasing = T), ]
top_sector_D3<-d3[1,1]
top_sector_D3

#4.Second best sector based on count of investments in the above mentioned countries:
second_best_sector_D1<-d1[2,1]
second_best_sector_D1

second_best_sector_D2<-d2[2,1]
second_best_sector_D2

second_best_sector_D3<-d3[2,1]
second_best_sector_D3

#5.Third best sector based on count of investments in the above mentioned countries:
third_best_sector_D1<-d1[3,1]
third_best_sector_D1

third_best_sector_D2<-d2[3,1]
third_best_sector_D2

third_best_sector_D3<-d3[3,1]
third_best_sector_D3

#6.Number of investments in the top sector in the above mentioned countries:
no_of_inv_top_sect_D1<-d1[1,2]
no_of_inv_top_sect_D1

no_of_inv_top_sect_D2<-d2[1,2]
no_of_inv_top_sect_D2

no_of_inv_top_sect_D3<-d3[1,2]
no_of_inv_top_sect_D3

#7.Number of investments in the second best sector in the above mentioned countries:
no_of_inv_second_sect_D1<-d1[2,2]
no_of_inv_second_sect_D1

no_of_inv_second_sect_D2<-d2[2,2]
no_of_inv_second_sect_D2

no_of_inv_second_sect_D3<-d3[2,2]
no_of_inv_second_sect_D3

#8.Number of investments in the third best sector in the above mentioned countries:
no_of_inv_third_sect_D1<-d1[3,2]
no_of_inv_third_sect_D1

no_of_inv_third_sect_D2<-d2[3,2]
no_of_inv_third_sect_D2

no_of_inv_third_sect_D3<-d3[3,2]
no_of_inv_third_sect_D3

#9.Company with highest investment for the top sector count wise:
#For USA:
D1_top_sectorcompany<-filter(D1, main_sector == d1$D1_sector[1])   
D1_top_company<-group_by(D1_top_sectorcompany,name) 
D1_top_company_sum<-summarise(D1_top_company, total_raised_amt_usd = sum(raised_amount_usd))
D1_top_company_sum<-arrange(D1_top_company_sum, desc(total_raised_amt_usd))
D1_highest_inv_company<-as.data.frame(D1_top_company_sum$name[1])
names(D1_highest_inv_company)<-"D1_highest_inv_company"
D1_highest_inv_company

#For GBR:
D2_top_sectorcompany<-filter(D2, main_sector == d2$D2_sector[1])   
D2_top_company<-group_by(D2_top_sectorcompany,name) 
D2_top_company_sum<-summarise(D2_top_company, total_raised_amt_usd = sum(raised_amount_usd))
D2_top_company_sum<-arrange(D2_top_company_sum, desc(total_raised_amt_usd))
D2_highest_inv_company<-as.data.frame(D2_top_company_sum$name[1])
names(D2_highest_inv_company)<-"D2_highest_inv_company"
D2_highest_inv_company

#For IND:
D3_top_sectorcompany<-filter(D3, main_sector == d3$D3_sector[1])   
D3_top_company<-group_by(D3_top_sectorcompany,name) 
D3_top_company_sum<-summarise(D3_top_company, total_raised_amt_usd = sum(raised_amount_usd))
D3_top_company_sum<-arrange(D3_top_company_sum, desc(total_raised_amt_usd))
D3_highest_inv_company<-as.data.frame(D3_top_company_sum$name[1])
names(D3_highest_inv_company)<-"D3_highest_inv_company"
D3_highest_inv_company

#10.Company with highest investment for the second best sector count wise:
#For USA:
D1_2nd_sectorcompany<-filter(D1, main_sector == d1$D1_sector[2])   
D1_2nd_company<-group_by(D1_2nd_sectorcompany,name) 
D1_2nd_company_sum<-summarise(D1_2nd_company, total_raised_amt_usd = sum(raised_amount_usd))
D1_2nd_company_sum<-arrange(D1_2nd_company_sum, desc(total_raised_amt_usd))
D1_2nd_highest_inv_company<-as.data.frame(D1_2nd_company_sum$name[1])
names(D1_2nd_highest_inv_company)<-"D1_2nd_highest_inv_company"
D1_2nd_highest_inv_company

#For GBR:
D2_2nd_sectorcompany<-filter(D2, main_sector == d2$D2_sector[2])   
D2_2nd_company<-group_by(D2_2nd_sectorcompany,name) 
D2_2nd_company_sum<-summarise(D2_2nd_company, total_raised_amt_usd = sum(raised_amount_usd))
D2_2nd_company_sum<-arrange(D2_2nd_company_sum, desc(total_raised_amt_usd))
D2_2nd_highest_inv_company<-as.data.frame(D2_2nd_company_sum$name[1])
names(D2_2nd_highest_inv_company)<-"D2_2nd_highest_inv_company"
D2_2nd_highest_inv_company

#For IND:
D3_2nd_sectorcompany<-filter(D3, main_sector == d3$D3_sector[2])   
D3_2nd_company<-group_by(D3_2nd_sectorcompany,name) 
D3_2nd_company_sum<-summarise(D3_2nd_company, total_raised_amt_usd = sum(raised_amount_usd))
D3_2nd_company_sum<-arrange(D3_2nd_company_sum, desc(total_raised_amt_usd))
D3_2nd_highest_inv_company<-as.data.frame(D3_2nd_company_sum$name[1])
names(D3_2nd_highest_inv_company)<-"D3_2nd_highest_inv_company"
D3_2nd_highest_inv_company


 









