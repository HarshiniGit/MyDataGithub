# Install the required packages and libraries

install.packages("readr")
install.packages("tidyr")
install.packages("lubridate")
install.packages("ggplot2")
install.packages("grid")
install.packages("gridExtra")
install.packages("dplyr")

library(readr)
library(tidyr)
library(lubridate)
library(ggplot2)
library(grid)
library(dplyr)
library(gridExtra)


#loading the uber data set into a data frame
Uber_Request <- read.csv("Uber Request Data.csv",header = T, stringsAsFactors = FALSE)

# looking at data
str(Uber_Request)

# data Cleaning 
Uber_Request$Pickup.point <- as.factor(Uber_Request$Pickup.point)
Uber_Request$Status <- as.factor(Uber_Request$Status)
Uber_Request$Driver.id <- as.factor(Uber_Request$Driver.id)

# Data Cleaning - The date and time are in an inconsistent format, using lubridate library to parse into common R format
Uber_Request$Request.timestamp <- parse_date_time(x = Uber_Request$Request.timestamp, orders = c("%d %m %Y %H%M","%d %m %Y %H:%M:%S"), locale = "English")
Uber_Request$Drop.timestamp <- parse_date_time(x = Uber_Request$Drop.timestamp, orders = c("%d %m %Y %H%M","%d %m %Y %H:%M:%S"), locale = "English")

# Sorting the data frame in ascending order of Driver.id and Request Time
Uber_Request <- Uber_Request[order(Uber_Request$Driver.id, Uber_Request$Request.timestamp),]

#Calculate the trip timings
Uber_Request$triptime<-as.numeric(Uber_Request$Drop.timestamp-Uber_Request$Request.timestamp)
Average_trip_time <- mean(!is.na(Uber_Request$triptime))*60

# Getting the hours from Request time and Drop time
Uber_Request1 <- separate(data = Uber_Request, col = "Request.timestamp", into = c("req.date","req.time"), sep = " ")
Uber_Request2 <- separate(data = Uber_Request1, col = "Drop.timestamp", into = c("drop.date","drop.time"), sep = " ")
Uber_Request2$Req.hrs <- as.factor(substring(Uber_Request2$req.time,0,2))
Uber_Request2$drop.hrs <- as.factor(substring(Uber_Request2$drop.time,0,2))

# demand and supply at airport and city

airport_demand <- ggplot(subset(Uber_Request2, Uber_Request2$Pickup.point == "Airport"), aes(Req.hrs))+
  geom_bar(fill = "blue") + labs(title ="Demand at Airport(Requests)")+
  theme(plot.title = element_text(hjust = 0.5))+ylim(0,500)
airport_supply <- ggplot(subset(subset(Uber_Request2, Uber_Request2$Pickup.point == "Airport"),!is.na(drop.hrs)), aes(drop.hrs))+
  geom_bar(fill = "red") + labs(title ="Supply at Airport(hours)")+
  theme(plot.title = element_text(hjust = 0.5))+ylim(0,500)

city_demand <- ggplot(subset(Uber_Request2, Uber_Request2$Pickup.point == "City"), aes(Req.hrs))+
  geom_bar(fill = "blue") + labs(title ="Demand at City(Requests)")+
  theme(plot.title = element_text(hjust = 0.5))+ylim(0,500)
city_supply <- ggplot(subset(subset(Uber_Request2, Uber_Request2$Pickup.point == "City"),!is.na(drop.hrs)), aes(drop.hrs))+
  geom_bar(fill = "red") + labs(title ="Supply at City(Drops)")+
  theme(plot.title = element_text(hjust = 0.5))+ylim(0,500)

# Overall demand and supply trend
grid.arrange(airport_demand, airport_supply, city_demand, city_supply, nrow = 2, ncol = 2)


# Demand & Supply together at Airport
Demand_and_Supply_at_Airport <- ggplot(subset(Uber_Request2, Uber_Request2$Pickup.point == "Airport")) +
  geom_bar(aes(Req.hrs), fill = c("blue"))+ geom_bar(aes(drop.hrs),fill = c("red"),position = "dodge")+
  ylim(0,500) + labs(title = "From Airport (Blue = Request for Cab, Red = Availability (after Drops))") + 
  theme(plot.title = element_text(hjust = 0.5)) + xlab("Hrs of the day")

# Demand & Supply together at City
Demand_and_Supply_at_City <- ggplot(subset(Uber_Request2, Uber_Request2$Pickup.point == "City")) +
  geom_bar(aes(Req.hrs), fill = c("blue"))+ geom_bar(aes(drop.hrs),fill = c("red"),position = "dodge")+
  ylim(0,500) + labs(title = "From City (Blue = Request for Cab, Red = Availability (after Drops))") + 
  theme(plot.title = element_text(hjust = 0.5)) + xlab("Hrs of the day")

# Demand and Supply  Comparision
grid.arrange(Demand_and_Supply_at_Airport, Demand_and_Supply_at_City, ncol = 2)

# Plotting the Data to see the trends in request time vs Status based on pickup point

# pick up is at Airport
Uber_Request_Airport <- ggplot(subset(Uber_Request2, Uber_Request2$Pickup.point == "Airport"), aes(Req.hrs, fill = Status))
Uber_Request_Airport <- Uber_Request_Airport + geom_bar() + ylim(0,500) + labs(title = "From Airport") + theme(plot.title = element_text(hjust = 0.5))


# pick up at the city
Uber_Request_City <- ggplot(subset(Uber_Request2, Uber_Request2$Pickup.point == "City"), aes(Req.hrs, fill = Status))
Uber_Request_City <- Uber_Request_City + geom_bar() + ylim(0,500) + labs(title = "From City") + theme(plot.title = element_text(hjust = 0.5))


# Cancelled and No car available case at Airport
Uber_Cancelled_Airport <- ggplot(subset(Uber_Request2, Uber_Request2$Pickup.point == "Airport" & Uber_Request2$Status == "Cancelled"), aes(Req.hrs))+
  geom_bar(fill = "blue") + labs(title = "Cancel Status at Airport")+ theme(plot.title = element_text(hjust = 0.5))

Uber_not_available_at_Airport <- ggplot(subset(Uber_Request2, Uber_Request2$Pickup.point == "Airport" & Uber_Request2$Status == "No Cars Available"), aes(Req.hrs))+
  geom_bar(fill = "red") + labs(title = "No Cars Available at Airport")+ theme(plot.title = element_text(hjust = 0.5))


grid.arrange(Uber_Cancelled_Airport, Uber_not_available_at_Airport, ncol = 2)

# Cancelled and No car available Case at city
Uber_Cancelled_in_City <- ggplot(subset(Uber_Request2, Uber_Request2$Pickup.point == "City" & Uber_Request2$Status == "Cancelled"), aes(Req.hrs))+
  geom_bar(fill = "blue") + labs(title = "Cancel Status at City")+ theme(plot.title = element_text(hjust = 0.5))
Uber_no_cab_in_City <- ggplot(subset(Uber_Request2, Uber_Request2$Pickup.point == "City" & Uber_Request2$Status == "No Cars Available"), aes(Req.hrs))+
  geom_bar(fill = "red") + labs(title = "No Cars Available at City")+ theme(plot.title = element_text(hjust = 0.5))

grid.arrange(Uber_Cancelled_in_City, Uber_no_cab_in_City, ncol = 2)